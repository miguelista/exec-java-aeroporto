package com.company;

import java.util.concurrent.Semaphore;

public class pista {

    public static void main(String[] args) {
        // write your code here
        int permissões = 2;
        Semaphore semaforo = new Semaphore(permissões);

    }
}
