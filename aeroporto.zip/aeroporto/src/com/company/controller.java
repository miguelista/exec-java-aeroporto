package com.company;

import java.util.concurrent.Semaphore;

public class controller extends Thread {


        public int idAviao;
    public  int posVoar;
    public  int posDecolagem;
    public Semaphore semaforo;

        public controller(int idAviao, Semaphore semaforo) {
            this.idAviao = idAviao;
            this.semaforo = semaforo;
        }
        @Override
        public void run() {
            aviaoespera();
            //--seção critica--
            try {


                //tenta executar linhas
                semaforo.acquire();
            } catch (InterruptedException e) {
                //tratamento de exceções
            } finally {
                // funcionamento correto
                semaforo.release();

                //--fim seção critica--

                aviaoDecolagem();
                aviaoVoando();
                }
            }





        public void aviaoespera() {


    }


    public void aviaoDecolagem() {
        int tempoManobra = (int)((Math.random() * 401) + 300);
        try {
            sleep(tempoManobra);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int tempotaxiando = (int)((Math.random() * 501) + 500);
        try {
            sleep(tempotaxiando);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int tempoDecolagem = (int)((Math.random() * 201) + 600);
        try {
            sleep(tempoDecolagem);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int tempoAfastamento = (int)((Math.random() * 501) + 300);
        try {
            sleep(tempoAfastamento);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int tempoTotal2 =  tempotaxiando + tempoDecolagem;
        System.out.println("#"+idAviao+" foi o "+posVoar+"o. a voar");
        posVoar++;
    }

    public void aviaoVoando() {
    }

}

